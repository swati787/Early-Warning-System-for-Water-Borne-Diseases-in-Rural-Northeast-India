from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)

# load trained model
model = joblib.load("risk_model.pkl")


# HOME PAGE
@app.route("/")
def home():
    return render_template("home.html")


# PREDICTION PAGE
@app.route("/predict_page")
def predict_page():
    return render_template("predict.html")


# GRAPHS PAGE
@app.route("/graphs")
def graphs():
    return render_template("graphs.html")

@app.route('/models')
def models():
    accuracies = {
        "Random Forest": 92,
        "KNN": 85,
        "SVM": 88,
        "Logistic Regression": 87
    }
    return render_template("model.html", accuracies=accuracies)



# ABOUT PAGE
@app.route("/about")
def about():
    return render_template("about.html")


# ML PREDICTION
@app.route("/predict", methods=["POST"])
def predict():

    data = request.get_json()

    season = int(data["season"])
    total = int(data["total"])

    if total == 0:
        risk = "Low Risk"
    else:
        prediction = model.predict([[season, total]])[0]

        if prediction == 2:
            risk = "High Risk"
        elif prediction == 1:
            risk = "Medium Risk"
        else:
            risk = "Low Risk"

    return jsonify({"risk": risk})


if __name__ == "__main__":
    app.run(debug=True)
