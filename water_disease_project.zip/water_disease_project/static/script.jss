function predict() {

let d = Number(document.getElementById("diarrhea").value);
let t = Number(document.getElementById("typhoid").value);
let c = Number(document.getElementById("cholera").value);
let h = Number(document.getElementById("hepatitis").value);

let season = Number(document.getElementById("season").value);

let total = d + t + c + h;

fetch("/predict", {

method: "POST",

headers: {
"Content-Type": "application/json"
},

body: JSON.stringify({
season: season,
total: total
})

})

.then(response => response.json())

.then(data => {

document.getElementById("result").innerHTML =
"Total Cases: " + total +
"<br>Risk Level: " + data.risk;

})

}