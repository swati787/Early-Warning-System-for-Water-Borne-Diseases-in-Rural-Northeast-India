import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize
from sklearn.model_selection import train_test_split
import joblib

# Load dataset
df = pd.read_excel("dataset.xlsx")

# Create total cases
df["Total_Cases"] = (
    df["Diarrhea_Cases"] +
    df["Typhoid_Cases"] +
    df["Cholera_Cases"] +
    df["HepatitisA_Cases"]
)

# Create risk label
def risk_label(x):
    if x > 30:
        return 2
    elif x >= 15:
        return 1
    else:
        return 0

df["Risk_Level"] = df["Total_Cases"].apply(risk_label)

# Encode season
df["Season"] = df["Season"].astype("category").cat.codes

# Features & target
X = df[["Season", "Total_Cases"]]
y = df["Risk_Level"]

# 🔥 SPLIT (VERY IMPORTANT)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Train model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Save model
joblib.dump(model, "risk_model.pkl")

# -----------------------------
# 🔥 ROC-AUC PART
# -----------------------------

# Ensure static folder exists
if not os.path.exists("static"):
    os.makedirs("static")

# Convert to binary
y_test_bin = label_binarize(y_test, classes=[0,1,2])
n_classes = y_test_bin.shape[1]

# Predict probabilities
y_score = model.predict_proba(X_test)

# Compute ROC
fpr = dict()
tpr = dict()
roc_auc = dict()

for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Plot
plt.figure(figsize=(8,6))

colors = ['blue', 'orange', 'green']
labels = ['Low Risk', 'Medium Risk', 'High Risk']

for i in range(n_classes):
    plt.plot(fpr[i], tpr[i], color=colors[i],
             label=f'{labels[i]} (AUC = {roc_auc[i]:.2f})')

plt.plot([0,1],[0,1],'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC-AUC Curve")
plt.legend(loc="lower right")

# Save image
plt.savefig("static/risk_roc.png")
plt.close()

print("✅ ROC generated successfully!")