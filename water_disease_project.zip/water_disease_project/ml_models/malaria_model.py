def predict_malaria(fever, chills, headache):

    if fever == "yes" and chills == "yes":
        return "Malaria Risk High"

    if fever == "yes":
        return "Malaria Possible"

    return "Low Risk"