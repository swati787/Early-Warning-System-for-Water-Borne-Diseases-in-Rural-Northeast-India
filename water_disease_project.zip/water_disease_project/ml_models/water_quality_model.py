def predict_water_quality(ph, turbidity, temperature):

    if ph < 6 or ph > 8.5:
        return "Unsafe Water"

    if turbidity > 5:
        return "Unsafe Water"

    return "Safe Water"