def predict_typhoid(fever, stomach_pain, weakness):

    if fever == "yes" and stomach_pain == "yes":
        return "Typhoid Risk High"

    if fever == "yes":
        return "Typhoid Possible"

    return "Typhoid Unlikely"