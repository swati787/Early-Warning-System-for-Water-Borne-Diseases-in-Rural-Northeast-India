def predict_cholera(diarrhea, vomiting, dehydration):

    if diarrhea == "yes" and dehydration == "yes":
        return "Cholera Risk High"

    if diarrhea == "yes":
        return "Possible Cholera"

    return "Low Risk"